function e(e) {
	let t = String(e).trim().match(/^(?:(\d+):)?(\d{2}):(\d{2})[.,](\d{3})$/);
	if (!t) return NaN;
	let [, n, r, i, a] = t;
	return Number(r) >= 60 || Number(i) >= 60 ? NaN : Number(n || 0) * 3600 + Number(r) * 60 + Number(i) + Number(a) / 1e3;
}
function t(e) {
	return String(e).replace(/<[^>]*>/g, "").replace(/\{\\[^}]*\}/g, "").replace(/&(?:amp|lt|gt|quot|apos|nbsp);/g, (e) => ({
		"&amp;": "&",
		"&lt;": "<",
		"&gt;": ">",
		"&quot;": "\"",
		"&apos;": "'",
		"&nbsp;": " "
	})[e]).trim();
}
function n(n) {
	if (typeof n != "string" || n.length > 5242880) throw Error("Use an SRT or VTT subtitle file smaller than 5 MB.");
	let r = n.replace(/^\uFEFF/, "").replace(/\r\n?/g, "\n").split("\n"), i = [];
	for (let n = 0; n < r.length; n++) {
		let a = r[n].match(/^\s*(\S+)\s*-->\s*(\S+)/);
		if (!a) continue;
		let o = e(a[1]), s = e(a[2]), c = [];
		for (; n + 1 < r.length && r[n + 1].trim() && !r[n + 1].includes("-->");) c.push(r[++n]);
		let l = t(c.join("\n"));
		if (Number.isFinite(o) && Number.isFinite(s) && o >= 0 && s > o && l && i.push({
			id: `cue-${i.length}`,
			start: o,
			end: s,
			text: l
		}), i.length > 2e4) throw Error("This file has too many subtitle lines.");
	}
	if (!i.length) throw Error("No timed subtitle lines found. Choose an SRT or WebVTT file.");
	return i.sort((e, t) => e.start - t.start || e.end - t.end);
}
//#endregion
//#region extension/popup.js
var r = document.querySelector("#status");
document.querySelector("#open").addEventListener("click", async () => {
	let e = document.querySelector("#open");
	e.disabled = !0, r.textContent = "Opening the study panel…";
	try {
		let [e] = await chrome.tabs.query({
			active: !0,
			currentWindow: !0
		});
		if (!e?.id || !/^https?:/.test(e.url || "")) throw Error("Open an ordinary web page with a video first.");
		let t = document.querySelector("#target").files[0], i = document.querySelector("#english").files[0], a = t ? n(await t.text()) : [], o = i ? n(await i.text()) : [];
		await chrome.scripting.executeScript({
			target: { tabId: e.id },
			files: ["overlay.js"]
		});
		let s = await chrome.tabs.sendMessage(e.id, {
			type: "vocabdrawer:open",
			lang: document.querySelector("#lang").value,
			cues: a,
			english: o
		});
		if (!s?.ok) throw Error(s?.error || "The study panel could not open.");
		r.textContent = "Panel opened. Use your imported tracks, or the player’s exposed captions.";
	} catch (e) {
		r.textContent = e.message;
	} finally {
		e.disabled = !1;
	}
});
//#endregion
